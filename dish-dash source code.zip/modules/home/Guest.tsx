import Image from "next/image";
import { useState } from "react";
import { Autoplay } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import styles from "./Guest.module.scss";

import Button from "@/components/Button/Button";
import { setLocalStorageItem } from "@/utils/storageUtils";
import "swiper/css";

const carouselData = [
  {
    title: "Unlock Savings with Every Order",
    subtitle: "Enjoy $1 Off on Every Purchase",
    imgURL:
      "https://images.getbento.com/accounts/22022076ca31682d32e6a3253b8e9e7c/media/images/77298federalist-pig-summer-specials-2024_web.jpg?w=1200&fit=crop&auto=compress,format&crop=focalpoint&fp-x=0.5&fp-y=0.3",
  },
  {
    title: "Discover New Restaurants",
    subtitle: "Explore and Save on a Wide Variety of Menus",
    imgURL:
      "https://images.getbento.com/accounts/22022076ca31682d32e6a3253b8e9e7c/media/images/51169june_2024_korean_spread.jpg?w=1200&fit=crop&auto=compress,format&crop=focalpoint&fp-x=0.5&fp-y=0.5",
  },
  {
    title: "Enjoy Dining from Home",
    subtitle: "Order Easily and Save Instantly",
    imgURL:
      "https://images.getbento.com/accounts/22022076ca31682d32e6a3253b8e9e7c/media/images/4440IMG_4865.JPG?w=1200&fit=crop&auto=compress,format&crop=focalpoint&fp-x=0.5&fp-y=0.5",
  },
];

const Guest = () => {
  const [first, setFirst] = useState(0);

  const handleLogin = () => {
    setLocalStorageItem("LOGIN", "true");
  };

  return (
    <div className={styles.container}>
      <div className={styles.title}>
        <h1 className={`${styles.title1}`}>Dish</h1>
        <h1 className={`${styles.title2}`}> &nbsp;Dash</h1>
      </div>

      <Swiper
        spaceBetween={0}
        slidesPerView={1}
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        loop={true}
        modules={[Autoplay]}
        className={styles.homeSwiper}
      >
        {carouselData.map((data, index) => (
          <SwiperSlide key={index}>
            <div className={styles.imageCover}>
              <Image
                priority={true}
                className={`d-block w-100 ${styles.swiperSlide}`}
                width={1200}
                height={900}
                src={data.imgURL}
                alt={`Slide ${index}`}
              />
              <div className={styles.overlay}>
                <p className={styles.overlayTitle}>{data.title}</p>
                <p className={styles.overlaySubtitle}>{data.subtitle}</p>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      <div className={styles.loginBtn}>
        <Button onClick={handleLogin}>Login</Button>
      </div>
    </div>
  );
};

export default Guest;
