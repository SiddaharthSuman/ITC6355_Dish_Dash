import { useState } from "react";
import styles from "./Guest.module.scss";

import Button from "@/components/Button/Button";
import { removeLocalStorageItem } from "@/utils/storageUtils";
import Image from "next/image";
import "swiper/css";

import { useRouter } from "next/navigation";
import LocationIcon from "../../public/icons/location.svg";

const restaurantData = [
  {
    name: "Pasta Paradise",
    imageDescription:
      "A delicious plate of spaghetti carbonara with creamy sauce, crispy pancetta, and a sprinkle of Parmesan cheese.",
    discount: "5% off",
  },
  {
    name: "Burger Bonanza",
    imageDescription:
      "A juicy cheeseburger with a perfectly cooked beef patty, melted cheese, fresh lettuce, tomato, and a side of golden fries.",
    discount: "7% off",
  },
  {
    name: "Sushi Sensations",
    imageDescription:
      "A beautiful sushi platter featuring an assortment of nigiri, sashimi, and maki rolls, garnished with fresh wasabi and pickled ginger.",
    discount: "10% off",
  },
  {
    name: "Pizza Perfection",
    imageDescription:
      "A classic margherita pizza with a crispy thin crust, fresh tomato sauce, mozzarella cheese, and basil leaves.",
    discount: "8% off",
  },
  {
    name: "Taco Triumph",
    imageDescription:
      "A vibrant assortment of tacos filled with various ingredients such as grilled chicken, beef, fish, and fresh vegetables, topped with cilantro and lime.",
    discount: "6% off",
  },
  {
    name: "Salad Symphony",
    imageDescription:
      "A fresh, colorful salad bowl with mixed greens, cherry tomatoes, cucumbers, red onions, feta cheese, and a light vinaigrette dressing.",
    discount: "5% off",
  },
  {
    name: "Grill Galore",
    imageDescription:
      "A perfectly grilled steak with grill marks, served with roasted vegetables and a side of mashed potatoes.",
    discount: "7% off",
  },
  {
    name: "Dessert Delights",
    imageDescription:
      "A decadent chocolate cake slice with rich, moist layers, chocolate frosting, and a drizzle of chocolate sauce.",
    discount: "5% off",
  },
  {
    name: "Seafood Sensations",
    imageDescription:
      "A fresh seafood platter with shrimp, oysters, and crab, garnished with lemon wedges and parsley.",
    discount: "6% off",
  },
  {
    name: "Vegan Vibrance",
    imageDescription:
      "A colorful vegan Buddha bowl with quinoa, avocado, roasted sweet potatoes, chickpeas, spinach, and a drizzle of tahini dressing.",
    discount: "5% off",
  },
  {
    name: "Curry Corner",
    imageDescription:
      "A rich, creamy chicken curry served with fluffy basmati rice and naan bread, garnished with cilantro.",
    discount: "7% off",
  },
  {
    name: "BBQ Bliss",
    imageDescription:
      "A platter of smoky barbecue ribs with a side of coleslaw, baked beans, and cornbread.",
    discount: "6% off",
  },
  {
    name: "Pancake Palace",
    imageDescription:
      "A stack of fluffy pancakes topped with maple syrup, fresh berries, and a dollop of whipped cream.",
    discount: "5% off",
  },
  {
    name: "Soup Sanctuary",
    imageDescription:
      "A comforting bowl of tomato basil soup served with a slice of crusty bread and a sprig of basil.",
    discount: "5% off",
  },
  {
    name: "Dim Sum Delight",
    imageDescription:
      "A variety of dim sum items including steamed dumplings, pork buns, and spring rolls, served with soy sauce and chili oil.",
    discount: "7% off",
  },
  {
    name: "Mediterranean Magic",
    imageDescription:
      "A platter of falafel, hummus, tabbouleh, and pita bread, accompanied by fresh vegetables and olives.",
    discount: "5% off",
  },
];

const locationData = [
  { name: "Boston", state: "Massachusetts" },
  {
    name: "New York",
    state: "New York",
  },
  {
    name: "Los Angeles",
    state: "California",
  },
  {
    name: "Chicago",
    state: "Illinois",
  },
  {
    name: "Houston",
    state: "Texas",
  },
  {
    name: "Phoenix",
    state: "Arizona",
  },
  {
    name: "Philadelphia",
    state: "Pennsylvania",
  },
  {
    name: "San Antonio",
    state: "Texas",
  },
  {
    name: "San Diego",
    state: "California",
  },
  {
    name: "Dallas",
    state: "Texas",
  },
  {
    name: "San Jose",
    state: "California",
  },
];

const Logged = () => {
  const router = useRouter();
  const [location, setLocation] = useState(
    `${locationData[0].name} - ${locationData[0].state}`
  );

  const handleLogout = () => {
    removeLocalStorageItem("LOGIN");
  };

  const handleLocation = () => {
    const randomIndex = Math.floor(Math.random() * locationData.length);
    setLocation(
      `${locationData[randomIndex].name} - ${locationData[randomIndex].state}`
    );
  };

  const goToMenu = () => {
    router.push("menu");
  };

  return (
    <div className={styles.container}>
      <div className={styles.title}>
        <h1 className={`${styles.title1}`}>Dish</h1>
        <h1 className={`${styles.title2}`}> &nbsp;Dash</h1>
      </div>

      <div className="container">
        <div className={`row ${styles.restaurantGrid}`}>
          {restaurantData.map((restaurant, index) => (
            <div
              key={index}
              className={`col-md-4 ${styles.restaurantContainer}`}
              onClick={goToMenu}
            >
              <div className={styles.imageContainer}>
                <Image
                  alt={restaurant.imageDescription}
                  src={`/images/image${index + 1}.webp`}
                  height={300}
                  width={300}
                />
              </div>

              <p>{restaurant.name}</p>
              <p>Get {restaurant.discount}</p>
            </div>
          ))}
        </div>
      </div>

      <div className={styles.locationBtn}>
        <Button onClick={handleLocation}>
          <LocationIcon />
          &nbsp;{location}
        </Button>
      </div>

      <div className={styles.loginBtn}>
        <Button onClick={handleLogout}>Logout</Button>
      </div>
    </div>
  );
};

export default Logged;
