"use client";

import Button from "@/components/Button/Button";
import {
  removeLocalStorageItem,
  setLocalStorageItem,
} from "@/utils/storageUtils";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";
import ShoppingCart from "../../../public/icons/shopping-cart.svg";
import styles from "./page.module.scss";

const rawMenu = [
  {
    name: "Caprese Salad",
    description: "Fresh mozzarella, tomatoes, and basil with a balsamic glaze.",
    category: "Appetizer",
    price: 8.5,
    fileName: "food1.webp",
  },
  {
    name: "Bruschetta",
    description: "Grilled bread topped with diced tomatoes, garlic, and basil.",
    category: "Appetizer",
    price: 7.0,
    fileName: "food2.webp",
  },
  {
    name: "Lobster Bisque",
    description: "Creamy soup made with fresh lobster and a hint of sherry.",
    category: "Soup",
    price: 12.0,
    fileName: "food3.webp",
  },
  {
    name: "Caesar Salad",
    description:
      "Romaine lettuce, croutons, and Parmesan cheese with Caesar dressing.",
    category: "Salad",
    price: 9.0,
    fileName: "food4.webp",
  },
  {
    name: "Grilled Chicken Sandwich",
    description:
      "Grilled chicken breast with lettuce, tomato, and mayo on a brioche bun.",
    category: "Sandwich",
    price: 11.5,
    fileName: "food5.webp",
  },
  {
    name: "Turkey Club",
    description: "Turkey, bacon, lettuce, tomato, and mayo on toasted bread.",
    category: "Sandwich",
    price: 10.5,
    fileName: "food6.webp",
  },
  {
    name: "Beef Tacos",
    description:
      "Three tacos filled with seasoned beef, lettuce, cheese, and salsa.",
    category: "Main Course",
    price: 12.0,
    fileName: "food7.webp",
  },
  {
    name: "Vegetable Stir-Fry",
    description:
      "Mixed vegetables stir-fried with soy sauce and served over rice.",
    category: "Main Course",
    price: 11.0,
    fileName: "food8.webp",
  },
  {
    name: "Shrimp Scampi",
    description:
      "Shrimp sautéed in garlic, butter, and white wine, served over pasta.",
    category: "Main Course",
    price: 18.0,
    fileName: "food9.webp",
  },
  {
    name: "Chicken Alfredo",
    description:
      "Grilled chicken breast served over fettuccine pasta with Alfredo sauce.",
    category: "Main Course",
    price: 15.0,
    fileName: "food10.webp",
  },
  {
    name: "Filet Mignon",
    description:
      "Tender filet mignon grilled to perfection, served with mashed potatoes.",
    category: "Main Course",
    price: 25.0,
    fileName: "food11.webp",
  },
  {
    name: "Roasted Salmon",
    description:
      "Roasted salmon fillet served with a side of quinoa and vegetables.",
    category: "Main Course",
    price: 20.0,
    fileName: "food12.webp",
  },
  {
    name: "Cheesecake",
    description:
      "Creamy cheesecake with a graham cracker crust and strawberry topping.",
    category: "Dessert",
    price: 7.0,
    fileName: "food13.webp",
  },
  {
    name: "Chocolate Mousse",
    description:
      "Rich chocolate mousse topped with whipped cream and chocolate shavings.",
    category: "Dessert",
    price: 6.5,
    fileName: "food14.webp",
  },
  {
    name: "Creme Brulee",
    description: "Classic French dessert with a caramelized sugar crust.",
    category: "Dessert",
    price: 8.0,
    fileName: "food15.webp",
  },
  {
    name: "Breakfast Burrito",
    description:
      "Scrambled eggs, cheese, and sausage wrapped in a warm tortilla.",
    category: "Breakfast",
    price: 9.0,
    fileName: "food16.webp",
  },
  {
    name: "French Toast",
    description:
      "Thick slices of bread dipped in egg batter and grilled to perfection, served with syrup.",
    category: "Breakfast",
    price: 8.5,
    fileName: "food17.webp",
  },
  {
    name: "Omelette",
    description:
      "Three-egg omelette with your choice of fillings, served with toast.",
    category: "Breakfast",
    price: 8.0,
    fileName: "food18.webp",
  },
];

interface MenuItem {
  name: string;
  description: string;
  category: string;
  price: number;
  fileName: string;
}

const Menu = () => {
  const [cart, setCart] = useState<Array<MenuItem>>([]);
  const router = useRouter();

  const groupMenuByCategory = (menuItems: MenuItem[]) => {
    return menuItems.reduce((acc: any, item: MenuItem) => {
      if (!acc[item.category]) {
        acc[item.category] = [];
      }
      acc[item.category].push(item);
      return acc;
    }, {});
  };

  const seg = groupMenuByCategory(rawMenu);

  const handleLogout = () => {
    removeLocalStorageItem("LOGIN");
    router.push("/");
  };

  const handleCart = (menuItem: MenuItem) => {
    setCart([...cart, menuItem]);
  };

  const goToCheckout = () => {
    //TODO: Send cart details to LocalStorage
    setLocalStorageItem("CART", JSON.stringify(cart));
    router.push("/checkout");
  };

  return (
    <div className={styles.container}>
      <div className={styles.title}>
        <h1 className={`${styles.title1}`}>Dish</h1>
        <h1 className={`${styles.title2}`}> &nbsp;Dash</h1>
      </div>
      <div className="container">
        {Object.keys(seg).map((cat, index) => (
          <div key={index}>
            <p className={styles.categoryText}>{cat}</p>

            {seg[cat].map((item: MenuItem, idx: number) => (
              <div className={styles.itemContainer} key={idx}>
                <div className={styles.imageContainer}>
                  <Image
                    alt={item.description}
                    width={200}
                    height={200}
                    src={`/images/${item.fileName}`}
                  ></Image>
                </div>
                <div className={styles.detailsContainer}>
                  <div className={styles.nameDescContainer}>
                    <p className={styles.itemName}>{item.name}</p>
                    <p className={styles.itemDesc}>{item.description}</p>
                  </div>
                  <div className={styles.bottomContainer}>
                    <p className={styles.itemPrice}>${item.price.toFixed(2)}</p>
                    <Button
                      disabled={cart.includes(item)}
                      onClick={() => handleCart(item)}
                    >
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
      <div className={styles.topRightControls}>
        <div className={styles.cartContainer} onClick={goToCheckout}>
          <ShoppingCart />
          <span className={styles.cartBadge}>{cart.length}</span>
        </div>
        <Button onClick={handleLogout}>Logout</Button>
      </div>
    </div>
  );
};

export default Menu;
