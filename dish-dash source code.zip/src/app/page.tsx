"use client";
import { getLocalStorageItem } from "@/utils/storageUtils";
import { useEffect, useState } from "react";
import Guest from "../../modules/home/Guest";
import Logged from "../../modules/home/Logged";

export default function Home() {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleStorageChange = () => {
    console.log("storage event occured");
    const loggedInStatus = getLocalStorageItem("LOGIN");

    console.log("setting new state of loggedin", !!loggedInStatus);
    setLoggedIn(!!loggedInStatus);
  };

  useEffect(() => {
    const loggedInStatus = getLocalStorageItem("LOGIN");
    setLoggedIn(!!loggedInStatus);

    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  return (
    <main className={`container-fluid`}>
      <div className="row">
        {/* {JSON.stringify(loggedIn)} */}
        {!loggedIn ? <Guest /> : <Logged />}
      </div>
    </main>
  );
}
