import React from "react";
import "./page.scss";

const generateOrderNumber = () => {
  return Math.floor(Math.random() * 1000000000)
    .toString()
    .padStart(9, "0");
};

const PaymentSuccess: React.FC = () => {
  const orderNumber = generateOrderNumber();

  return (
    <div className="order-placed-container">
      <h1>Order Placed Successfully!</h1>
      <div className="order-details">
        <p>Your order number is:</p>
        <h2>{orderNumber}</h2>
      </div>
      <div className="order-actions">
        <button>View Order Details</button>
        <button>Continue Shopping</button>
      </div>
    </div>
  );
};

export default PaymentSuccess;
