"use client";

import Button from "@/components/Button/Button";
import {
  getLocalStorageItem,
  removeLocalStorageItem,
} from "@/utils/storageUtils";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import styles from "./page.module.scss";

interface MenuItem {
  name: string;
  description: string;
  category: string;
  price: number;
  fileName: string;
}

const Checkout = () => {
  const [cart, setCart] = useState<Array<MenuItem>>([]);
  const [qty, setQty] = useState(0);
  const [subtotal, setSubtotal] = useState(0);

  const router = useRouter();

  useEffect(() => {
    console.log("cart items", cart);
    const items = getLocalStorageItem("CART");
    console.log("received", items);
    if (items) {
      setCart(JSON.parse(items));
    }
  }, []);

  useEffect(() => {
    //TODO: calc data
    let quant = 0;
    let stotal = 0;
    console.log("cart", cart);
    cart.forEach((item) => {
      quant++;
      stotal += item.price;
    });

    setQty(quant);
    setSubtotal(stotal);
  }, [cart]);

  const handleLogout = () => {
    removeLocalStorageItem("LOGIN");
    router.push("/");
  };

  const goToPayment = () => {
    // removeLocalStorageItem("LOGIN");
    router.push("/payment");
  };

  const handleCart = (menuItem: MenuItem) => {
    setCart([...cart, menuItem]);
  };

  return (
    <div className={styles.container}>
      <div className={styles.title}>
        <h1 className={`${styles.title1}`}>Dish</h1>
        <h1 className={`${styles.title2}`}> &nbsp;Dash</h1>
      </div>
      <div className={`container `}>
        <p className={styles.categoryText}>Your cart</p>
        <div className={`row ${styles.checkoutList}`}>
          <p className={`${styles.itemTitleName} col-6`}>NAME</p>
          <p className={`${styles.itemTitleQty} col-2`}>QTY</p>
          <p className={`${styles.itemTitlePrice} col-4`}>PRICE</p>
        </div>
        {cart.map((item: MenuItem, index) => (
          <div key={index} className="row">
            <p className={`${styles.itemName} col-6`}>{item.name}</p>
            <p className={`${styles.itemQty} col-2`}>1</p>
            <p className={`${styles.itemPrice} col-4`}>
              ${item.price.toFixed(2)}
            </p>
          </div>
        ))}

        <hr />

        <div className="row">
          <p className={`${styles.itemName} col-6`}>Subtotal</p>
          <p className={`${styles.itemQty} col-2`}>{qty}</p>
          <p className={`${styles.itemPrice} col-4`}>${subtotal.toFixed(2)}</p>
        </div>

        <hr />

        <div className="row">
          <p className={`${styles.itemName} col-6`}>Discount (5%)</p>
          <p className={`${styles.itemQty} col-2`}></p>
          <p className={`${styles.itemPrice} col-4`}>
            - ${(subtotal * 0.05).toFixed(2)}
          </p>
        </div>

        <hr />

        <div className="row">
          <p className={`${styles.itemName} col-6`}>Total</p>
          <p className={`${styles.itemQty} col-2`}>{qty}</p>
          <p className={`${styles.itemPrice} col-4`}>
            ${(subtotal * 0.95).toFixed(2)}
          </p>
        </div>

        <hr />

        <div className={`row ${styles.checkoutBtnContainer}`}>
          <div className="col-12">
            <Button onClick={goToPayment}>Checkout</Button>
          </div>
        </div>
      </div>
      <div className={styles.topRightControls}>
        <Button onClick={handleLogout}>Logout</Button>
      </div>
    </div>
  );
};

export default Checkout;
