"use client";
import { useRouter } from "next/navigation";
import "./page.scss";

const Payment = () => {
  const router = useRouter();

  const goToSuccess = () => {
    router.push("/payment-success");
  };
  return (
    <div className="payments-container">
      <h1>Pay Bill</h1>
      <div className="payment-form">
        <div className="form-group">
          <label htmlFor="cardNumber">Card Number</label>
          <input
            type="text"
            id="cardNumber"
            name="cardNumber"
            placeholder="1234 5678 9012 3456"
            value={`1234 5678 9012 3456`}
          />
        </div>
        <div className="form-group">
          <label htmlFor="expiryDate">Expiry Date</label>
          <input
            type="text"
            id="expiryDate"
            name="expiryDate"
            placeholder="MM/YY"
            value={`01/25`}
          />
        </div>
        <div className="form-group">
          <label htmlFor="cvv">CVV</label>
          <input
            type="text"
            id="cvv"
            name="cvv"
            placeholder="123"
            value={`123`}
          />
        </div>
        <div className="form-group">
          <label htmlFor="cardName">Cardholder Name</label>
          <input
            type="text"
            id="cardName"
            name="cardName"
            placeholder="John Doe"
            value={`John Doe`}
          />
        </div>
        <button onClick={goToSuccess}>Submit Payment</button>
      </div>
    </div>
  );
};

export default Payment;
