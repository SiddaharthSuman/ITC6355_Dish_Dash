import { MouseEventHandler } from "react";
import styles from "./Button.module.scss";

interface ButtonProps {
  children: any;
  disabled?: boolean;
  onClick?: MouseEventHandler;
}

const Button = ({ children, disabled = false, onClick }: ButtonProps) => {
  return (
    <div>
      <button disabled={disabled} className={styles.innerBtn} onClick={onClick}>
        {children}
      </button>
    </div>
  );
};

export default Button;
