/**
 * Sets an item in LocalStorage.
 * @param key - The key under which the value will be stored.
 * @param value - The value to be stored.
 */
export function setLocalStorageItem(key: string, value: string): void {
  localStorage.setItem(key, value);
  window.dispatchEvent(new Event("storage"));
}

/**
 * Retrieves an item from LocalStorage.
 * @param key - The key of the item to be retrieved.
 * @returns The value of the item, or null if not found.
 */
export function getLocalStorageItem(key: string): string | null {
  return localStorage.getItem(key);
}

/**
 * Removes an item from LocalStorage.
 * @param key - The key of the item to be removed.
 */
export function removeLocalStorageItem(key: string): void {
  localStorage.removeItem(key);
  window.dispatchEvent(new Event("storage"));
}